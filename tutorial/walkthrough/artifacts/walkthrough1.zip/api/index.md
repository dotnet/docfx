
# PLACEHOLDER
TODO: Add .NET projects to *src* folder and run `docfx` to generate a **REAL** *API Documentation*!
