Details1
------------

This is a detailed description.
![Image](../images/details1_image.png)