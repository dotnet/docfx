function transform(model, _attrs){
  model._tocPath = _attrs._tocPath;
  model._tocRel = _attrs._tocRel;
  return model;
}
